<?php get_header(); ?>
<div id="container-employees">
	<?php
	$employeepost = array('post_type' => 'aqualaw_employees');
	$loop = new WP_Query($employeepost);
	?>
		<?php $count =1; ?>
		<ul class="employees">
		<?php while ($loop->have_posts() ) : $loop->the_post(); ?>
			<li class="employee <?php if($count%2==0) : echo 'even'; endif; ?>">
				<div id="contact-icon">
					<div id="employee-image"><?php the_post_thumbnail('our-people-icon'); ?></div>
					<div id="employee-info">
						<div id="name">
							<?php the_title(); ?>
							<a href="<?php the_permalink(); ?>" class="button">More</a>
						</div>
						<ul class="position">
							<li><?php the_field('position'); ?></li>
							<li><a href="mailto:<?php the_field('email_address'); ?>"><?php the_field('email_address'); ?></a></li>
							<li><?php the_field('company_phone_number', 'option')?> x<?php the_field('phone_number_extension')?></li>
						</ul>
					</div><!--Close employee info-->
				</div>
			</li>
		<?php $count++; endwhile; ?>
		</ul>
</div>
<?php get_footer(); ?>