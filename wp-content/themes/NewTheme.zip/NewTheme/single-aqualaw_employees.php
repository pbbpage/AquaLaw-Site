<?php
	/*Template Name: Employee Profile Template
	*/
get_header(); ?>
<?php while (have_posts()) : the_post(); ?>
	<article id="article">
		<h id="article-title"><?php the_title(); ?></h>
		<?php the_content();?>
	</article>
	<div id="sidebar">
		<div id="image-wrap">
		</div>
	</div><!--End sidebar-->
<?php endwhile; ?>
<?php get_footer(); ?>