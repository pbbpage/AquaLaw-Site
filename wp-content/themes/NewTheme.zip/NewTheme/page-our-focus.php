<?php get_header(); ?>
<div id="page-main">
<div id="sidebar">
	<h2 class="widgettitle">Core Services</h2>
	<?php
	$rows = get_field('our-focus-repeater');
	if($rows)
	{
		echo '<ul>';
		foreach($rows as $row)
		{
			$output = '<li id="our-focus"><div id="icon-wrap"><img id="icon" src="%s" alt="%s"><div id="text-wrap"><h3>%s</h3></div></div></li>';
			echo sprintf($output, $row['our_focus_images']['url'], $row['our_focus_images']['title'], $row['our_focus_images']['title']);
		}
	}
	?>
</div><!--Close sidebar-->
</div><!--Close Page main-->
<?php get_footer(); ?>