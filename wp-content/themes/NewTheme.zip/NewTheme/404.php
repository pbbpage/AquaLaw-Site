<?php get_header() ?>
<p>We're sorry, the page you are trying to access is not available at this time.  Please try again later.</p>
<?php get_footer() ?>