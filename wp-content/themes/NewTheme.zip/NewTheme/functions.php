<?php
define( 'TEMPPATH', get_bloginfo('stylesheet_directory'));
define( 'IMAGES', TEMPPATH. "/images");

add_theme_support('nav-menus');
if ( function_exists('register_nav_menus')) {
	register_nav_menus(
		array(
			'main' => 'Main Nav'
		)
	);
}

if(function_exists("register_options_page"))
{
    register_options_page('Home');
    register_options_page('Contact Information');
  
 }
 
include_once('advanced-custom-fields/acf.php');

if ( function_exists('register_sidebars') )  
    register_sidebars(5);   

add_theme_support($feature);

add_image_size( 'photo-display', 1200, 400, True );

add_image_size('our-people-icon', 465, 237, True);

add_theme_support('post-thumbnails');


?>
